<template>
  <Head title="Home"></Head>
  <App>
    <v-container>
      <h2 class="text-4xl">Remember Me</h2>
    </v-container>

    <v-card class="mt-5" v-if="profile">
      <v-tabs v-model="tab" align-tabs="center" color="deep-purple-accent-4">
        <v-tab :value="1" @click="changeTab(1)">Bio</v-tab>
        <v-tab :value="2" @click="changeTab(2)">Media</v-tab>
      </v-tabs>

      <div :value="1" v-show="tab === 1">
        <v-container fluid class="text-center">
            <v-img :src="coverPictureUrl" class="mb-3" />
          <div class="mb-5">
            <h1>{{ fullName }}</h1>
            <h2>{{ profile? profile.title : '' }}</h2>


                  <p>{{ profile ? profile.bio : '' }}</p>
                  <p><strong>Birth Date:</strong> {{ profile? profile.birth_date :'' }}</p>
                  <p><strong>Death Date:</strong> {{ profile ? profile.death_date  : ''}}</p>
                  <p><strong>Description:</strong> {{ profile ? profile.description : '' }}</p>
                  <p><strong>Relationship:</strong> {{ profile ? profile.relationship : '' }}</p>



          </div>
        </v-container>
      </div>

      <!-- Media Tab -->
      <div :value="2" v-show="tab === 2">
        <v-container fluid class="text-center">
            <v-img :src="profilePictureUrl" class="mb-3" />
          <v-card v-if="props.profile ? props.profile.images : ''">
            <v-card-title>Images</v-card-title>
            <v-card-text>
              <v-row>
                <v-col v-for="(image, index) in profile.images" :key="index" cols="12" md="4">
                  <v-img :src="image" class="mb-3" />
                </v-col>
              </v-row>
            </v-card-text>
          </v-card>
        </v-container>
      </div>
    </v-card>
    <div class="text-center text-red" v-else>
        <h1>No Profile found!</h1>
    </div>
  </App>
</template>

<script setup>
import Snackbar from "@/Components/Snackbar.vue";
import App from "./Layouts/App.vue";
import { Head } from "@inertiajs/vue3";
import { ref, computed } from "vue";
components: {
  App, Head;
}

let props = defineProps({
  profile: Object,
});

const tab = ref(1);
const show = ref(true);

const changeTab = (newTab) => {
  tab.value = newTab;
  show.value = true;
};
console.log(props.profile);

const coverPictureUrl = computed(() => props.profile? props.profile.cover_photo : '');
const profilePictureUrl = computed(() => props.profile ? props.profile.profile_picture :'');
const fullName = computed(() => {
  return `${props.profile ? props.profile.first_name : ''} ${props.profile ? props.profile.middle_name : ''} ${props.profile ? props.profile.last_name : ''}`;
});

let snackbar = ref(false);
let text = ref("");
</script>
